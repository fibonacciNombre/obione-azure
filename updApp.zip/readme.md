# Node JS empty site
[![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)